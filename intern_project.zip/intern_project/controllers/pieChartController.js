const Product = require('../models/Product');

const getPieChartData = async (req, res) => {
  const { month } = req.query;

  try {
    const transactions = await Product.find({ dateOfSale: { $regex: new RegExp(month, 'i') } });
    const categories = {};

    transactions.forEach(item => {
      categories[item.category] = (categories[item.category] || 0) + 1;
    });

    res.status(200).json(categories);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching pie chart data', error });
  }
};

module.exports = getPieChartData;
