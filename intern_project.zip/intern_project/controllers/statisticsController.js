const Product = require('../models/Product');

const getStatistics = async (req, res) => {
  const { month } = req.query;

  try {
    // Get transactions for the given month
    const transactions = await Product.find({ dateOfSale: { $regex: new RegExp(month, 'i') } });

    const totalSaleAmount = transactions.reduce((sum, item) => sum + (item.sold ? item.price : 0), 0);
    const soldItems = transactions.filter(item => item.sold).length;
    const unsoldItems = transactions.length - soldItems;

    res.status(200).json({ totalSaleAmount, soldItems, unsoldItems });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching statistics', error });
  }
};

module.exports = getStatistics;
