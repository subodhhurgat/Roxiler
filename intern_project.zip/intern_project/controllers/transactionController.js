const Product = require('../models/Product');

const listTransactions = async (req, res) => {
  const { page = 1, perPage = 10, search = '', month } = req.query;
  const query = {};

  // Filter by month
  if (month) {
    query.dateOfSale = { $regex: new RegExp(month, 'i') }; // Case insensitive match
  }

  // Search functionality
  if (search) {
    query.$or = [
      { title: { $regex: search, $options: 'i' } },
      { description: { $regex: search, $options: 'i' } },
      { price: search }
    ];
  }

  try {
    // Fetch transactions with pagination and search
    const transactions = await Product.find(query)
      .skip((page - 1) * perPage)
      .limit(Number(perPage));
    
    // Get total number of documents
    const total = await Product.countDocuments(query);

    res.status(200).json({ transactions, total });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching transactions', error });
  }
};

module.exports = listTransactions;
