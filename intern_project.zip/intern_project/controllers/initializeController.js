const axios = require('axios');
const Product = require('../models/Product');

const initializeDatabase = async (req, res) => {
  try {
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    const data = response.data;

    await Product.insertMany(data);
    res.status(200).json({ message: 'Database initialized with seed data.' });
  } catch (error) {
    res.status(500).json({ message: 'Error initializing database.', error });
  }
};

module.exports = initializeDatabase;
